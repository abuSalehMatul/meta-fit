<?php 

return [
    "SHOPIFY_APP_SECRET"=>"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",
    "SHOPIFY_APP_KEY"=>"4261daf8e8ba1eae4f9898d848c3f727",
    "APP_URL" => "https://8f28ed3de5f7.ngrok.io",
    "SCRIPT_TAG_SRC" => "https://8f28ed3de5f7.ngrok.io/frontend/matulScriptTag.js",
];