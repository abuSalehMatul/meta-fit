<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MetaField extends Model
{
    protected $fillable  =['name', 'status'];
}
